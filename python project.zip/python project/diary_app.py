import os
import json
import threading
import datetime
import tkinter as tk
from tkinter import simpledialog, messagebox, filedialog, scrolledtext

import speech_recognition as sr
from cryptography.fernet import Fernet
from fpdf import FPDF
 
KEY_FILE = "secret.kry"
DATA_FILE = "entries.dat"
PASSPHRASE = "open my diary" # voice passphrase

def generate_key():
    key = Fernet.generate_key()
    with open(KEY_FILE, "wb") as f:
        f.write(key)
    return key

def load_key():
    if not os.path.exists(KEY_FILE):
        return generate_key()
    return open(KEY_FILE, "rb").read()

fernet = Fernet(load_key())

def encrypt_data(obj):
    raw = json.dumps(obj).encode("utf-8")
    return fernet.encrypt(raw)

def decrypt_data(token):
    try:
        raw = fernet.decrypt(token)
        return json.loads(raw.decode("utf-8"))
    except Exception:
        return {"entries": []}

def save_entries(data):
    enc = encrypt_data(data)
    with open(DATA_FILE, "wb") as f:
        f.write(enc)

def load_entries():
    if not os.path.exists(DATA_FILE):
        return {"entries": []}
    with open(DATA_FILE, "rb") as f:
        token = f.read()
    return decrypt_data(token)

# ---------- Voice unlock ----------
recognizer = sr.Recognizer()

def listen_for_passphrase(timeout=5, phrase_time_limit=5):
    with sr.Microphone() as source:
        recognizer.adjust_for_ambient_noise(source, duration=0.7)
        print("Listening for passphrase...")
        audio = recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
    try:
        text = recognizer.recognize_google(audio)
        print("Heard:", text)
        return text.lower()
    except sr.WaitTimeoutError:
        return ""
    except Exception as e:
        print("STT error:", e)
        return ""

# ---------- GUI ----------
class DiaryApp:
    def __init__(self, root):
        self.root = root
        root.title("Secret Voice-Locked Diary")
        root.geometry("600x500")

        self.data = load_entries()

        self.locked = True

        self.top_frame = tk.Frame(root)
        self.top_frame.pack(pady=10)

        self.unlock_btn = tk.Button(self.top_frame, text="Unlock with Voice", command=self.try_voice_unlock)
        self.unlock_btn.pack(side="left", padx=5)

        self.password_btn = tk.Button(self.top_frame, text="Unlock with Password", command=self.try_password_unlock)
        self.password_btn.pack(side="left", padx=5)

        self.lock_btn = tk.Button(self.top_frame, text="Lock", command=self.lock, state="disabled")
        self.lock_btn.pack(side="left", padx=5)

        self.export_btn = tk.Button(self.top_frame, text="Export to PDF", command=self.export_pdf, state="disabled")
        self.export_btn.pack(side="left", padx=5)

        self.text_area = scrolledtext.ScrolledText(root, wrap="word", state="disabled")
        self.text_area.pack(expand=True, fill="both", padx=10, pady=10)

        self.bottom_frame = tk.Frame(root)
        self.bottom_frame.pack(pady=5)

        self.add_btn = tk.Button(self.bottom_frame, text="Add Entry", command=self.add_entry, state="disabled")
        self.add_btn.pack(side="left", padx=5)

        self.refresh_view_btn = tk.Button(self.bottom_frame, text="Refresh View", command=self.refresh_view, state="disabled")
        self.refresh_view_btn.pack(side="left", padx=5)

        self.status_label = tk.Label(root, text="Locked 🔒")
        self.status_label.pack(side="bottom", pady=6)

    def try_voice_unlock(self):
        self.unlock_btn.config(state="disabled")
        threading.Thread(target=self._voice_thread, daemon=True).start()

    def _voice_thread(self):
        heard = listen_for_passphrase()
        if heard and PASSPHRASE in heard:
            self.unlock()
        else:
            messagebox.showwarning("Voice unlock failed", "Could not verify passphrase via voice.\nTry again or use password.")
        self.unlock_btn.config(state="normal")

    def try_password_unlock(self):
        pwd = simpledialog.askstring("Password", "Enter backup password (this is a fallback):", show="*")
        # Simple fallback — in production, you'd store hashed password
        if pwd is None:
            return
        if pwd == "12345":   # change or implement set-password flow
            self.unlock()
        else:
            messagebox.showerror("Wrong", "Password incorrect.")

    def unlock(self):
        self.locked = False
        self.status_label.config(text="Unlocked 🔓")
        self.add_btn.config(state="normal")
        self.lock_btn.config(state="normal")
        self.refresh_view_btn.config(state="normal")
        self.export_btn.config(state="normal")
        self.text_area.config(state="normal")
        self.refresh_view()

    def lock(self):
        self.locked = True
        self.status_label.config(text="Locked 🔒")
        self.add_btn.config(state="disabled")
        self.lock_btn.config(state="disabled")
        self.refresh_view_btn.config(state="disabled")
        self.export_btn.config(state="disabled")
        self.text_area.config(state="disabled")
        self.text_area.delete("1.0", tk.END)

    def add_entry(self):
        title = simpledialog.askstring("Title", "Entry title:")
        if title is None:
            return
        content = simpledialog.askstring("Entry", "Write your entry (single-line for demo):")
        if content is None:
            return
        entry = {
            "title": title,
            "content": content,
            "created_at": datetime.datetime.now().isoformat()
        }
        self.data.setdefault("entries", []).append(entry)
        save_entries(self.data)
        messagebox.showinfo("Saved", "Entry saved and encrypted.")
        self.refresh_view()

    def refresh_view(self):
        self.text_area.config(state="normal")
        self.text_area.delete("1.0", tk.END)
        entries = self.data.get("entries", [])
        for e in reversed(entries):
            t = f"{e['created_at']} — {e['title']}\n{e['content']}\n\n"
            self.text_area.insert(tk.END, t)
        self.text_area.config(state="normal")

    def export_pdf(self):
        entries = self.data.get("entries", [])
        if not entries:
            messagebox.showinfo("No entries", "No entries to export.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if not path:
            return
        pdf = FPDF()
        pdf.set_auto_page_break(auto=True, margin=15)
        pdf.add_page()
        pdf.set_font("Arial", size=12)
        for e in entries:
            pdf.cell(0, 8, txt=e['created_at'], ln=1)
            pdf.set_font("Arial", "B", 14)
            pdf.multi_cell(0, 8, txt=e['title'])
            pdf.set_font("Arial", size=12)
            pdf.multi_cell(0, 8, txt=e['content'])
            pdf.ln(4)
        pdf.output(path)
        messagebox.showinfo("Exported", f"PDF exported to: {path}")

if __name__ == "__main__":
    root = tk.Tk()
    app = DiaryApp(root)
    root.mainloop()
